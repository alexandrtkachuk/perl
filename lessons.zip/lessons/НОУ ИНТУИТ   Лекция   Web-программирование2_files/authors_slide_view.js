$(document).ready(function() {
  $('.author-slide-wrapper .author-names .name').
    /*bind('click', function() {
      var $this = $(this);
      var id = $this.attr('id');
      id = id.substr(12, id.length);
      $photo = $('#author-photo-'+id);
      if($photo.hasClass('opened'))
      {
        $photo.slideUp('slow').removeClass('opened');
      }
      else
      {
        $photo.css('display','block').addClass('opened');
      }
    }).*/
    bind('mouseout', function() {
      var $this = $(this);
      var id = $this.attr('id');
      id = id.substr(12, id.length);
      $photo = $('#author-photo-'+id);
      if(!$photo.hasClass('opened'))
      {
        $photo.hide();
      }
    }).
    bind('mouseover', function() {
      var $this = $(this);
      var id = $this.attr('id');
      id = id.substr(12, id.length);
      $photo = $('#author-photo-'+id);
      if(!$photo.hasClass('opened'))
      {
        $photo.show();
      }
    });
});