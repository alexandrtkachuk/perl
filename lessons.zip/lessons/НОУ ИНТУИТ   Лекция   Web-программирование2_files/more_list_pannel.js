$(document).ready(function() {
  $(".more-list-pannel .full-text-switch-control")
  .live('click', function(event) 
  {
    var $this = $(this);
    var $parent = $this.parent().parent();
    $parent.children('.breif-text-wrapper').hide();
    $parent.children('.full-text-wrapper').show();
    event.preventDefault();
    return false;
  });
  $(".more-list-pannel .brief-text-switch-control")
  .live('click', function(event) 
  {
    var $this = $(this);
    var $parent = $this.parent().parent();
    $parent.children('.full-text-wrapper').hide();
    $parent.children('.breif-text-wrapper').show();
    event.preventDefault();
    return false;
  });
})