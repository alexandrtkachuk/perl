$(document).ready(function(){
  $('#edit-search-theme-form-1').hint();
});