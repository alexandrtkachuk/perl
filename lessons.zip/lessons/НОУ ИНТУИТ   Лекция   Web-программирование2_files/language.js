$(document).ready(function(){
  $('.locale .ru a').attr('title', 'Русский язык');
  $('.locale .en a').attr('title', 'English');
});